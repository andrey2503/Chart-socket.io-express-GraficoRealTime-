var express=require('express');
// var chart=require('chart');
var app=express();
var server=require('http').Server(app);
var io=require('socket.io')(server);
app.use(express.static('public'));

io.on('connection',function(socket){
console.log("se conecto");
	socket.on('subir',function(data){
		console.log("se envia");
		io.sockets.emit('pintar',data);
	});

});

server.listen(8080,function(){
	console.log('servidor corriendo');
});