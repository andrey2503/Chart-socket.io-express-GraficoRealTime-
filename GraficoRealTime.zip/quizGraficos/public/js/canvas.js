var socket=io.connect("http://localhost:8080",{'forceNew':true});

var chart;
var pPinto=0,pPizza=0,pNachos=0,pSalchi=0;
var lienzo=null;
var canvas=null;
window.addEventListener('load',init,false);

function init(){
	 canvas=document.getElementById('lienzo').getContext('2d');
 // lienzo=canvas.getContext('2d');

}

function subirPinto(){
	pPinto=pPinto+1;
	data={labels:['Pinto','Pizza','Nachos','Salchipapicarnes'],
			datasets:[{
				label:"Grafica de comidas",
				backgroundColor: "rgba(255,99,132,0.2)",
            // borderColor: "rgba(255,99,132,1)",
            // borderWidth: 1,
            // hoverBackgroundColor: "rgba(255,99,132,0.4)",
            // hoverBorderColor: "rgba(255,99,132,1)",
				data:[pPinto,pPizza,pNachos,pSalchi]
			}]};
	socket.emit('subir',data);
}

function subirPizza(){
	pPizza=pPizza+1;
	data={labels:['Pinto','Pizza','Nachos','Salchipapicarnes'],
			datasets:[{
				label:"Grafica de comidas",
				backgroundColor: "rgba(255,99,132,0.2)",
            // borderColor: "rgba(255,99,132,1)",
            // borderWidth: 1,
            // hoverBackgroundColor: "rgba(255,99,132,0.4)",
            // hoverBorderColor: "rgba(255,99,132,1)",
				data:[pPinto,pPizza,pNachos,pSalchi]
			}]};
	socket.emit('subir',data);
}

function subirNacho(){
	pNachos=pNachos+1;
	data={labels:['Pinto','Pizza','Nachos','Salchipapicarnes'],
			datasets:[{
				label:"Grafica de comidas",
				backgroundColor: "rgba(255,99,132,0.2)",
            // borderColor: "rgba(255,99,132,1)",
            // borderWidth: 1,
            // hoverBackgroundColor: "rgba(255,99,132,0.4)",
            // hoverBorderColor: "rgba(255,99,132,1)",
				data:[pPinto,pPizza,pNachos,pSalchi]
			}]};
	socket.emit('subir',data);
}

function subirSalchi(){
	pSalchi=pSalchi+1;
	data={labels:['Pinto','Pizza','Nachos','Salchipapicarnes'],
			datasets:[{
				label:"Grafica de comidas",
				backgroundColor: "rgba(255,99,132,0.2)",
            // borderColor: "rgba(255,99,132,1)",
            // borderWidth: 1,
            // hoverBackgroundColor: "rgba(255,99,132,0.4)",
            // hoverBorderColor: "rgba(255,99,132,1)",
				data:[pPinto,pPizza,pNachos,pSalchi]
			}]};
	socket.emit('subir',data);
}



socket.on('pintar',function(data){
chart = new Chart(canvas,{type:"bar",data:data,options:"options"});
});


